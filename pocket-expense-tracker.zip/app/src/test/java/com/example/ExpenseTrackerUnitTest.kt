package com.example

import com.example.data.local.TransactionConverters
import com.example.data.model.AppLanguage
import com.example.data.model.CurrencyOption
import com.example.data.model.MonthYear
import com.example.data.model.TransactionCategory
import com.example.data.model.TransactionType
import com.example.ui.util.Formatters
import org.junit.Assert.assertEquals
import org.junit.Test

class ExpenseTrackerUnitTest {

    @Test
    fun `formatCurrency formats english and bengali digits accurately`() {
        val enFormatted = Formatters.formatCurrency(
            amount = 1250.5,
            currency = CurrencyOption.USD,
            language = AppLanguage.ENGLISH,
            showSign = true,
            isIncome = true
        )
        assertEquals("+$1,250.50", enFormatted)

        val bnFormatted = Formatters.formatCurrency(
            amount = 1250.0,
            currency = CurrencyOption.BDT,
            language = AppLanguage.BENGALI,
            showSign = true,
            isIncome = false
        )
        assertEquals("-৳১,২৫০", bnFormatted)
    }

    @Test
    fun `monthYear navigation wraps year boundaries properly`() {
        val jan = MonthYear(2026, 0)
        assertEquals(MonthYear(2025, 11), jan.previous())

        val dec = MonthYear(2026, 11)
        assertEquals(MonthYear(2027, 0), dec.next())
    }

    @Test
    fun `room type converters round trip all enums`() {
        val converters = TransactionConverters()
        TransactionType.entries.forEach { type ->
            val raw = converters.fromTransactionType(type)
            assertEquals(type, converters.toTransactionType(raw))
        }
        TransactionCategory.entries.forEach { cat ->
            val raw = converters.fromTransactionCategory(cat)
            assertEquals(cat, converters.toTransactionCategory(raw))
        }
    }

    @Test
    fun `currency and language helpers cycle and parse safely`() {
        assertEquals(CurrencyOption.USD, CurrencyOption.BDT.next())
        assertEquals(CurrencyOption.INR, CurrencyOption.USD.next())
        assertEquals(CurrencyOption.BDT, CurrencyOption.INR.next())
        assertEquals(AppLanguage.BENGALI, AppLanguage.fromCode("bn"))
        assertEquals(AppLanguage.ENGLISH, AppLanguage.fromCode("unknown"))
    }
}
