package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.TransactionCategory
import com.example.data.model.TransactionType

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val type: TransactionType,
    val amount: Double,
    val description: String,
    val category: TransactionCategory,
    val timestamp: Long,
    val createdAt: Long = System.currentTimeMillis()
)
