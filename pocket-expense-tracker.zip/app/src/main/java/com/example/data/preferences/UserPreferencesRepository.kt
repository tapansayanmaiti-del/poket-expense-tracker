package com.example.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.AppLanguage
import com.example.data.model.CurrencyOption
import java.util.Locale
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "pocket_expense_prefs")

class UserPreferencesRepository(private val context: Context) {
    private object Keys {
        val LANGUAGE_CODE = stringPreferencesKey("language_code")
        val CURRENCY_SYMBOL = stringPreferencesKey("currency_symbol")
    }

    private val defaultLanguage: AppLanguage
        get() = if (Locale.getDefault().language == "bn") AppLanguage.BENGALI else AppLanguage.ENGLISH

    val languageFlow: Flow<AppLanguage> = context.dataStore.data.map { prefs ->
        val code = prefs[Keys.LANGUAGE_CODE]
        if (code != null) AppLanguage.fromCode(code) else defaultLanguage
    }

    val currencyFlow: Flow<CurrencyOption> = context.dataStore.data.map { prefs ->
        val symbol = prefs[Keys.CURRENCY_SYMBOL]
        if (symbol != null) CurrencyOption.fromSymbol(symbol) else CurrencyOption.BDT
    }

    suspend fun setLanguage(language: AppLanguage) {
        context.dataStore.edit { prefs ->
            prefs[Keys.LANGUAGE_CODE] = language.code
        }
    }

    suspend fun setCurrency(currency: CurrencyOption) {
        context.dataStore.edit { prefs ->
            prefs[Keys.CURRENCY_SYMBOL] = currency.symbol
        }
    }
}
