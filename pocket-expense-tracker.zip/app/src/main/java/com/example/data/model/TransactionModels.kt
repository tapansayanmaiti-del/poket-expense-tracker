package com.example.data.model

enum class TransactionType {
    INCOME,
    EXPENSE
}

enum class TransactionCategory {
    FOOD,
    SHOPPING,
    TRAVEL,
    BILLS,
    OTHERS
}

enum class AppLanguage(val code: String) {
    ENGLISH("en"),
    BENGALI("bn");

    companion object {
        fun fromCode(code: String?): AppLanguage =
            entries.firstOrNull { it.code == code } ?: ENGLISH
    }
}

enum class CurrencyOption(val symbol: String, val label: String) {
    BDT("৳", "BDT"),
    USD("$", "USD"),
    INR("₹", "INR");

    fun next(): CurrencyOption {
        val list = entries
        return list[(ordinal + 1) % list.size]
    }

    companion object {
        fun fromSymbol(symbol: String?): CurrencyOption =
            entries.firstOrNull { it.symbol == symbol } ?: BDT
    }
}

data class MonthYear(val year: Int, val month: Int) {
    fun previous(): MonthYear =
        if (month == 0) MonthYear(year - 1, 11) else MonthYear(year, month - 1)

    fun next(): MonthYear =
        if (month == 11) MonthYear(year + 1, 0) else MonthYear(year, month + 1)
}
