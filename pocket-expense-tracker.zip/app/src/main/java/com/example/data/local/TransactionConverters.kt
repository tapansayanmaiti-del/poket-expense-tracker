package com.example.data.local

import androidx.room.TypeConverter
import com.example.data.model.TransactionCategory
import com.example.data.model.TransactionType

class TransactionConverters {
    @TypeConverter
    fun fromTransactionType(type: TransactionType): String = type.name

    @TypeConverter
    fun toTransactionType(value: String): TransactionType =
        TransactionType.entries.firstOrNull { it.name == value } ?: TransactionType.EXPENSE

    @TypeConverter
    fun fromTransactionCategory(category: TransactionCategory): String = category.name

    @TypeConverter
    fun toTransactionCategory(value: String): TransactionCategory =
        TransactionCategory.entries.firstOrNull { it.name == value } ?: TransactionCategory.OTHERS
}
