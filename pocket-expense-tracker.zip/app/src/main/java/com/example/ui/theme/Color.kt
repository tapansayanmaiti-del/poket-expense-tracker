package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand & Surface Palette (Tactile Warm Paper & Forest Emerald)
val ForestEmerald = Color(0xFF0C664A)
val ForestEmeraldDeep = Color(0xFF074632)
val MintVibrant = Color(0xFF14B885)
val MintSoft = Color(0xFF42D6A4)
val SoftSageWash = Color(0xFFE4F2EC)
val SoftSageDark = Color(0xFF1A342B)

val WarmAlabaster = Color(0xFFF7F6F2)
val CrispPaper = Color(0xFFFFFFFF)
val WarmSand = Color(0xFFECE9E1)
val SlateInk = Color(0xFF141C1A)
val MutedSlate = Color(0xFF5A6762)
val SubtleOutline = Color(0xFFD7DDD8)

val DeepPineBg = Color(0xFF0D1412)
val DeepPineSurface = Color(0xFF15201C)
val DeepPineElevated = Color(0xFF1D2C27)
val LightInk = Color(0xFFEAF2EE)
val MutedLightInk = Color(0xFF9FB0A9)
val DarkOutline = Color(0xFF2B3D36)

// Financial Semantic Colors
val IncomeGreenLight = Color(0xFF0E8A5D)
val IncomeGreenContainerLight = Color(0xFFDDF5EA)
val IncomeGreenDark = Color(0xFF5CE0AC)
val IncomeGreenContainerDark = Color(0xFF123B2B)

val ExpenseCoralLight = Color(0xFFD6453A)
val ExpenseCoralContainerLight = Color(0xFFFDE8E6)
val ExpenseCoralDark = Color(0xFFFF897D)
val ExpenseCoralContainerDark = Color(0xFF451C19)

// Category Signature Colors
val CategoryFoodColor = Color(0xFFE67E22)
val CategoryShoppingColor = Color(0xFF6C5CE7)
val CategoryTravelColor = Color(0xFF0097A7)
val CategoryBillsColor = Color(0xFFD63031)
val CategoryOthersColor = Color(0xFF5D736F)
