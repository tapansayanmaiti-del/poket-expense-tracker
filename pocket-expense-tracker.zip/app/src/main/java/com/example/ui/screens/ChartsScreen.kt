package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.PieChartOutline
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.components.CategoryDonutCard
import com.example.ui.components.MonthlyBarChartCard
import com.example.ui.theme.LocalLedgerColors
import com.example.ui.util.Formatters
import com.example.ui.util.str
import com.example.ui.viewmodel.ChartTab
import com.example.ui.viewmodel.ExpenseTrackerUiState

@Composable
fun ChartsScreen(
    uiState: ExpenseTrackerUiState,
    onPreviousMonth: () -> Unit,
    onNextMonth: () -> Unit,
    onChartTabChange: (ChartTab) -> Unit,
    onToggleLanguage: () -> Unit,
    onCycleCurrency: () -> Unit,
    modifier: Modifier = Modifier
) {
    val ledgerColors = LocalLedgerColors.current

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 760.dp)
                .fillMaxSize()
                .testTag("charts_screen_list"),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 104.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item(key = "charts_header") {
                LedgerTopHeader(
                    language = uiState.language,
                    currencySymbol = uiState.currency.symbol,
                    onToggleLanguage = onToggleLanguage,
                    onCycleCurrency = onCycleCurrency,
                    titleOverride = str(R.string.monthly_overview)
                )
            }

            item(key = "month_navigator") {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = onPreviousMonth,
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("previous_month_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowLeft,
                                contentDescription = str(R.string.cd_previous_month)
                            )
                        }

                        Text(
                            text = Formatters.formatMonthYear(uiState.selectedMonthYear, uiState.language),
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.testTag("selected_month_label")
                        )

                        IconButton(
                            onClick = onNextMonth,
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("next_month_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
                                contentDescription = str(R.string.cd_next_month)
                            )
                        }
                    }
                }
            }

            item(key = "monthly_summary_strip") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MonthlyStatTile(
                        label = str(R.string.total_income),
                        value = Formatters.formatCurrency(
                            uiState.monthlyIncome,
                            uiState.currency,
                            uiState.language
                        ),
                        accent = ledgerColors.income,
                        modifier = Modifier.weight(1f)
                    )
                    MonthlyStatTile(
                        label = str(R.string.total_expenses),
                        value = Formatters.formatCurrency(
                            uiState.monthlyExpense,
                            uiState.currency,
                            uiState.language
                        ),
                        accent = ledgerColors.expense,
                        modifier = Modifier.weight(1f)
                    )
                    MonthlyStatTile(
                        label = str(R.string.net_savings),
                        value = Formatters.formatCurrency(
                            uiState.monthlyNet,
                            uiState.currency,
                            uiState.language
                        ),
                        accent = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            if (uiState.categoryBreakdown.isEmpty()) {
                item(key = "empty_month_chart") {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("empty_chart_card"),
                        shape = RoundedCornerShape(22.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(28.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.PieChartOutline,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(48.dp)
                            )
                            Text(
                                text = str(R.string.empty_chart_title),
                                style = MaterialTheme.typography.titleLarge,
                                color = MaterialTheme.colorScheme.onSurface,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = str(R.string.empty_chart_subtitle),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            } else {
                item(key = "category_donut") {
                    CategoryDonutCard(
                        breakdown = uiState.categoryBreakdown,
                        totalExpense = uiState.monthlyExpense,
                        currency = uiState.currency,
                        language = uiState.language
                    )
                }
            }

            item(key = "monthly_bar_chart") {
                MonthlyBarChartCard(
                    chartTab = uiState.chartTab,
                    dailySpending = uiState.dailySpending,
                    sixMonthTrend = uiState.sixMonthTrend,
                    currency = uiState.currency,
                    language = uiState.language,
                    onTabChange = onChartTabChange
                )
            }
        }
    }
}

@Composable
private fun MonthlyStatTile(
    label: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = value,
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = accent,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
