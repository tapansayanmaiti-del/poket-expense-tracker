package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.AppLanguage
import com.example.data.model.CurrencyOption
import com.example.ui.theme.LocalLedgerColors
import com.example.ui.util.Formatters
import com.example.ui.util.str
import com.example.ui.util.titleResId
import com.example.ui.viewmodel.CategorySpend
import com.example.ui.viewmodel.ChartTab
import com.example.ui.viewmodel.DailySpend
import com.example.ui.viewmodel.MonthlyTrend

@Composable
fun CategoryDonutCard(
    breakdown: List<CategorySpend>,
    totalExpense: Double,
    currency: CurrencyOption,
    language: AppLanguage,
    modifier: Modifier = Modifier
) {
    val sweepAnimation = remember(breakdown) { Animatable(0f) }
    LaunchedEffect(breakdown) {
        sweepAnimation.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 650, easing = FastOutSlowInEasing)
        )
    }

    val sliceColors = breakdown.map { it.category.color() }
    val trackColor = MaterialTheme.colorScheme.surfaceVariant

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("category_donut_card"),
        shape = RoundedCornerShape(22.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
        tonalElevation = 1.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = str(R.string.category_breakdown),
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onSurface
            )

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(210.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.size(186.dp)) {
                    val strokeWidth = 28.dp.toPx()
                    val diameter = size.minDimension - strokeWidth
                    val topLeft = Offset(strokeWidth / 2f, strokeWidth / 2f)
                    val arcSize = Size(diameter, diameter)

                    drawArc(
                        color = trackColor,
                        startAngle = 0f,
                        sweepAngle = 360f,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = strokeWidth)
                    )

                    if (totalExpense > 0.0 && breakdown.isNotEmpty()) {
                        var startAngle = -90f
                        val gapDegrees = if (breakdown.size > 1) 3f else 0f
                        breakdown.forEachIndexed { index, item ->
                            val rawSweep = ((item.amount / totalExpense) * 360.0).toFloat()
                            val sweep = (rawSweep - gapDegrees).coerceAtLeast(1.5f) * sweepAnimation.value
                            drawArc(
                                color = sliceColors[index],
                                startAngle = startAngle,
                                sweepAngle = sweep,
                                useCenter = false,
                                topLeft = topLeft,
                                size = arcSize,
                                style = Stroke(width = strokeWidth, cap = StrokeCap.Butt)
                            )
                            startAngle += rawSweep
                        }
                    }
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = str(R.string.total_expenses),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = Formatters.formatCurrency(totalExpense, currency, language),
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                breakdown.forEach { item ->
                    val catColor = item.category.color()
                    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(30.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(catColor.copy(alpha = 0.14f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = item.category.icon(),
                                    contentDescription = null,
                                    tint = catColor,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = str(item.category.titleResId()),
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = Formatters.formatPercent(item.percentage, language),
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(end = 8.dp)
                            )
                            Text(
                                text = Formatters.formatCurrency(item.amount, currency, language),
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        LinearProgressIndicator(
                            progress = { (item.percentage / 100.0).toFloat().coerceIn(0f, 1f) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(50)),
                            color = catColor,
                            trackColor = catColor.copy(alpha = 0.14f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun MonthlyBarChartCard(
    chartTab: ChartTab,
    dailySpending: List<DailySpend>,
    sixMonthTrend: List<MonthlyTrend>,
    currency: CurrencyOption,
    language: AppLanguage,
    onTabChange: (ChartTab) -> Unit,
    modifier: Modifier = Modifier
) {
    val ledgerColors = LocalLedgerColors.current
    var selectedDailyIndex by remember(dailySpending) { mutableStateOf<Int?>(null) }
    var selectedMonthIndex by remember(sixMonthTrend) { mutableStateOf<Int?>(null) }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("monthly_bar_chart_card"),
        shape = RoundedCornerShape(22.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
        tonalElevation = 1.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = str(
                        if (chartTab == ChartTab.DAILY) R.string.daily_spending_title
                        else R.string.six_month_trend_title
                    ),
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f)
                )

                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(3.dp),
                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    ChartTabButton(
                        label = str(R.string.tab_daily),
                        selected = chartTab == ChartTab.DAILY,
                        onClick = { onTabChange(ChartTab.DAILY) },
                        modifier = Modifier.testTag("chart_tab_daily")
                    )
                    ChartTabButton(
                        label = str(R.string.tab_six_months),
                        selected = chartTab == ChartTab.SIX_MONTHS,
                        onClick = { onTabChange(ChartTab.SIX_MONTHS) },
                        modifier = Modifier.testTag("chart_tab_six_months")
                    )
                }
            }

            if (chartTab == ChartTab.DAILY) {
                val maxDayAmount = (dailySpending.maxOfOrNull { it.amount } ?: 0.0).coerceAtLeast(1.0)
                val highlightedDay = selectedDailyIndex?.let { idx ->
                    dailySpending.getOrNull(idx)
                }

                if (highlightedDay != null) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.primaryContainer
                    ) {
                        Text(
                            text = "${str(R.string.selected_day_label)} ${
                                Formatters.localizeDigits(highlightedDay.dayOfMonth.toString(), language)
                            }: ${Formatters.formatCurrency(highlightedDay.amount, currency, language)}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }

                val barColor = ledgerColors.expense
                val selectedBarColor = MaterialTheme.colorScheme.primary
                val baselineColor = MaterialTheme.colorScheme.outline

                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(156.dp)
                        .pointerInput(dailySpending) {
                            detectTapGestures { offset ->
                                if (dailySpending.isNotEmpty()) {
                                    val slotWidth = size.width.toFloat() / dailySpending.size
                                    val index = (offset.x / slotWidth)
                                        .toInt()
                                        .coerceIn(0, dailySpending.lastIndex)
                                    selectedDailyIndex = index
                                }
                            }
                        }
                ) {
                    val count = dailySpending.size.coerceAtLeast(1)
                    val slotWidth = size.width / count
                    val barWidth = (slotWidth * 0.62f).coerceAtLeast(3.dp.toPx())
                    val chartHeight = size.height - 12.dp.toPx()

                    drawLine(
                        color = baselineColor,
                        start = Offset(0f, chartHeight),
                        end = Offset(size.width, chartHeight),
                        strokeWidth = 1.dp.toPx()
                    )

                    dailySpending.forEachIndexed { index, item ->
                        val ratio = (item.amount / maxDayAmount).toFloat().coerceIn(0f, 1f)
                        val barHeight = if (item.amount > 0) {
                            (ratio * (chartHeight - 8.dp.toPx())).coerceAtLeast(4.dp.toPx())
                        } else {
                            2.dp.toPx()
                        }
                        val left = index * slotWidth + (slotWidth - barWidth) / 2f
                        val top = chartHeight - barHeight
                        val color = when {
                            selectedDailyIndex == index -> selectedBarColor
                            item.amount > 0 -> barColor
                            else -> baselineColor.copy(alpha = 0.45f)
                        }
                        drawRoundRect(
                            color = color,
                            topLeft = Offset(left, top),
                            size = Size(barWidth, barHeight),
                            cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    listOf(1, 8, 15, 22, dailySpending.size.coerceAtLeast(28)).forEach { day ->
                        Text(
                            text = Formatters.localizeDigits(day.toString(), language),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                val maxTrendAmount = sixMonthTrend
                    .maxOfOrNull { maxOf(it.income, it.expense) }
                    ?.coerceAtLeast(1.0) ?: 1.0

                val highlightedMonth = selectedMonthIndex?.let { sixMonthTrend.getOrNull(it) }
                if (highlightedMonth != null) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.primaryContainer
                    ) {
                        Text(
                            text = "${Formatters.formatMonthYear(highlightedMonth.monthYear, language)} — " +
                                "${str(R.string.transaction_type_income)}: ${Formatters.formatCurrency(highlightedMonth.income, currency, language)} • " +
                                "${str(R.string.transaction_type_expense)}: ${Formatters.formatCurrency(highlightedMonth.expense, currency, language)}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }

                // Legend
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    LegendDot(color = ledgerColors.income, label = str(R.string.transaction_type_income))
                    LegendDot(color = ledgerColors.expense, label = str(R.string.transaction_type_expense))
                }

                val incomeColor = ledgerColors.income
                val expenseColor = ledgerColors.expense
                val baselineColor = MaterialTheme.colorScheme.outline

                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(156.dp)
                        .pointerInput(sixMonthTrend) {
                            detectTapGestures { offset ->
                                if (sixMonthTrend.isNotEmpty()) {
                                    val slotWidth = size.width.toFloat() / sixMonthTrend.size
                                    val idx = (offset.x / slotWidth)
                                        .toInt()
                                        .coerceIn(0, sixMonthTrend.lastIndex)
                                    selectedMonthIndex = idx
                                }
                            }
                        }
                ) {
                    val count = sixMonthTrend.size.coerceAtLeast(1)
                    val slotWidth = size.width / count
                    val barWidth = (slotWidth * 0.28f).coerceAtLeast(6.dp.toPx())
                    val gap = 4.dp.toPx()
                    val chartHeight = size.height - 12.dp.toPx()

                    drawLine(
                        color = baselineColor,
                        start = Offset(0f, chartHeight),
                        end = Offset(size.width, chartHeight),
                        strokeWidth = 1.dp.toPx()
                    )

                    sixMonthTrend.forEachIndexed { index, item ->
                        val center = index * slotWidth + slotWidth / 2f

                        val incRatio = (item.income / maxTrendAmount).toFloat().coerceIn(0f, 1f)
                        val incHeight = if (item.income > 0) {
                            (incRatio * (chartHeight - 8.dp.toPx())).coerceAtLeast(4.dp.toPx())
                        } else 2.dp.toPx()
                        drawRoundRect(
                            color = incomeColor,
                            topLeft = Offset(center - barWidth - gap / 2f, chartHeight - incHeight),
                            size = Size(barWidth, incHeight),
                            cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
                        )

                        val expRatio = (item.expense / maxTrendAmount).toFloat().coerceIn(0f, 1f)
                        val expHeight = if (item.expense > 0) {
                            (expRatio * (chartHeight - 8.dp.toPx())).coerceAtLeast(4.dp.toPx())
                        } else 2.dp.toPx()
                        drawRoundRect(
                            color = expenseColor,
                            topLeft = Offset(center + gap / 2f, chartHeight - expHeight),
                            size = Size(barWidth, expHeight),
                            cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
                        )
                    }
                }

                Row(modifier = Modifier.fillMaxWidth()) {
                    sixMonthTrend.forEach { trend ->
                        Text(
                            text = Formatters.formatShortMonth(trend.monthYear, language),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LegendDot(color: Color, label: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(color)
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun ChartTabButton(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(9.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(9.dp),
        color = if (selected) MaterialTheme.colorScheme.surface else Color.Transparent,
        tonalElevation = if (selected) 2.dp else 0.dp
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium.copy(
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
            ),
            color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
        )
    }
}
