package com.example.ui.util

import android.content.Context
import android.content.res.Configuration
import android.content.res.Resources
import androidx.annotation.StringRes
import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import com.example.R
import com.example.data.model.AppLanguage
import com.example.data.model.CurrencyOption
import com.example.data.model.MonthYear
import com.example.data.model.TransactionCategory
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

val LocalAppResources = staticCompositionLocalOf<Resources> {
    error("LocalAppResources not provided")
}

val LocalAppLanguage = staticCompositionLocalOf { AppLanguage.ENGLISH }

fun createLocalizedResources(context: Context, language: AppLanguage): Resources {
    val locale = Locale(language.code)
    val config = Configuration(context.resources.configuration)
    config.setLocale(locale)
    return context.createConfigurationContext(config).resources
}

@Composable
@ReadOnlyComposable
fun str(@StringRes id: Int): String = LocalAppResources.current.getString(id)

object Formatters {
    private val bengaliDigits = charArrayOf('০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯')

    fun localizeDigits(input: String, language: AppLanguage): String {
        if (language != AppLanguage.BENGALI) return input
        val sb = StringBuilder(input.length)
        for (ch in input) {
            if (ch in '0'..'9') {
                sb.append(bengaliDigits[ch - '0'])
            } else {
                sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun formatCurrency(
        amount: Double,
        currency: CurrencyOption,
        language: AppLanguage,
        showSign: Boolean = false,
        isIncome: Boolean = true
    ): String {
        val absValue = kotlin.math.abs(amount)
        val symbols = DecimalFormatSymbols(Locale.ENGLISH)
        val pattern = if (absValue % 1.0 == 0.0) "#,##0" else "#,##0.00"
        val formatter = DecimalFormat(pattern, symbols)
        val formattedNumber = localizeDigits(formatter.format(absValue), language)
        val prefix = when {
            showSign && isIncome -> "+"
            showSign && !isIncome -> "-"
            amount < 0 -> "-"
            else -> ""
        }
        return "$prefix${currency.symbol}$formattedNumber"
    }

    fun formatPercent(value: Double, language: AppLanguage): String {
        val rounded = kotlin.math.round(value).toInt()
        return "${localizeDigits(rounded.toString(), language)}%"
    }

    fun formatMonthYear(monthYear: MonthYear, language: AppLanguage): String {
        val cal = Calendar.getInstance().apply {
            set(Calendar.YEAR, monthYear.year)
            set(Calendar.MONTH, monthYear.month)
            set(Calendar.DAY_OF_MONTH, 1)
        }
        val locale = if (language == AppLanguage.BENGALI) Locale("bn", "BD") else Locale.ENGLISH
        val sdf = SimpleDateFormat("MMMM yyyy", locale)
        return localizeDigits(sdf.format(cal.time), language)
    }

    fun formatShortMonth(monthYear: MonthYear, language: AppLanguage): String {
        val cal = Calendar.getInstance().apply {
            set(Calendar.YEAR, monthYear.year)
            set(Calendar.MONTH, monthYear.month)
            set(Calendar.DAY_OF_MONTH, 1)
        }
        val locale = if (language == AppLanguage.BENGALI) Locale("bn", "BD") else Locale.ENGLISH
        val sdf = SimpleDateFormat("MMM", locale)
        return sdf.format(cal.time)
    }

    fun formatDate(timestamp: Long, language: AppLanguage): String {
        val locale = if (language == AppLanguage.BENGALI) Locale("bn", "BD") else Locale.ENGLISH
        val sdf = SimpleDateFormat("dd MMM yyyy", locale)
        return localizeDigits(sdf.format(Date(timestamp)), language)
    }

    fun formatDateGroupHeader(
        timestamp: Long,
        language: AppLanguage,
        resources: Resources
    ): String {
        val nowCal = Calendar.getInstance()
        val targetCal = Calendar.getInstance().apply { timeInMillis = timestamp }

        if (isSameDay(nowCal, targetCal)) {
            return resources.getString(R.string.today)
        }
        val yesterdayCal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
        if (isSameDay(yesterdayCal, targetCal)) {
            return resources.getString(R.string.yesterday)
        }
        return formatDate(timestamp, language)
    }

    private fun isSameDay(a: Calendar, b: Calendar): Boolean =
        a.get(Calendar.YEAR) == b.get(Calendar.YEAR) &&
            a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)
}

@StringRes
fun TransactionCategory.titleResId(): Int = when (this) {
    TransactionCategory.FOOD -> R.string.category_food
    TransactionCategory.SHOPPING -> R.string.category_shopping
    TransactionCategory.TRAVEL -> R.string.category_travel
    TransactionCategory.BILLS -> R.string.category_bills
    TransactionCategory.OTHERS -> R.string.category_others
}
