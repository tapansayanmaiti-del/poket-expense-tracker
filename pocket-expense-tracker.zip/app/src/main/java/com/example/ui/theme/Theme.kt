package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.data.model.AppLanguage

@Immutable
data class LedgerSemanticColors(
    val income: Color,
    val incomeContainer: Color,
    val expense: Color,
    val expenseContainer: Color,
    val heroGradientStart: Color,
    val heroGradientEnd: Color,
    val categoryFood: Color,
    val categoryShopping: Color,
    val categoryTravel: Color,
    val categoryBills: Color,
    val categoryOthers: Color,
    val cardElevated: Color
)

private val LightSemanticColors = LedgerSemanticColors(
    income = IncomeGreenLight,
    incomeContainer = IncomeGreenContainerLight,
    expense = ExpenseCoralLight,
    expenseContainer = ExpenseCoralContainerLight,
    heroGradientStart = ForestEmerald,
    heroGradientEnd = ForestEmeraldDeep,
    categoryFood = CategoryFoodColor,
    categoryShopping = CategoryShoppingColor,
    categoryTravel = CategoryTravelColor,
    categoryBills = CategoryBillsColor,
    categoryOthers = CategoryOthersColor,
    cardElevated = CrispPaper
)

private val DarkSemanticColors = LedgerSemanticColors(
    income = IncomeGreenDark,
    incomeContainer = IncomeGreenContainerDark,
    expense = ExpenseCoralDark,
    expenseContainer = ExpenseCoralContainerDark,
    heroGradientStart = ForestEmerald,
    heroGradientEnd = DeepPineBg,
    categoryFood = CategoryFoodColor,
    categoryShopping = CategoryShoppingColor,
    categoryTravel = CategoryTravelColor,
    categoryBills = CategoryBillsColor,
    categoryOthers = CategoryOthersColor,
    cardElevated = DeepPineElevated
)

val LocalLedgerColors = staticCompositionLocalOf { LightSemanticColors }

private val DarkColorScheme = darkColorScheme(
    primary = MintSoft,
    onPrimary = ForestEmeraldDeep,
    primaryContainer = SoftSageDark,
    onPrimaryContainer = MintSoft,
    secondary = MintVibrant,
    onSecondary = ForestEmeraldDeep,
    secondaryContainer = DeepPineElevated,
    onSecondaryContainer = LightInk,
    tertiary = CategoryFoodColor,
    background = DeepPineBg,
    onBackground = LightInk,
    surface = DeepPineSurface,
    onSurface = LightInk,
    surfaceVariant = DeepPineElevated,
    onSurfaceVariant = MutedLightInk,
    outline = DarkOutline,
    error = ExpenseCoralDark,
    errorContainer = ExpenseCoralContainerDark
)

private val LightColorScheme = lightColorScheme(
    primary = ForestEmerald,
    onPrimary = CrispPaper,
    primaryContainer = SoftSageWash,
    onPrimaryContainer = ForestEmeraldDeep,
    secondary = MintVibrant,
    onSecondary = CrispPaper,
    secondaryContainer = SoftSageWash,
    onSecondaryContainer = ForestEmeraldDeep,
    tertiary = CategoryFoodColor,
    background = WarmAlabaster,
    onBackground = SlateInk,
    surface = CrispPaper,
    onSurface = SlateInk,
    surfaceVariant = WarmSand,
    onSurfaceVariant = MutedSlate,
    outline = SubtleOutline,
    error = ExpenseCoralLight,
    errorContainer = ExpenseCoralContainerLight
)

private val AppShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun PocketExpenseTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    language: AppLanguage = AppLanguage.ENGLISH,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    val semanticColors = if (darkTheme) DarkSemanticColors else LightSemanticColors
    val typography = buildAppTypography(isBengali = language == AppLanguage.BENGALI)

    CompositionLocalProvider(LocalLedgerColors provides semanticColors) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = typography,
            shapes = AppShapes,
            content = content
        )
    }
}
