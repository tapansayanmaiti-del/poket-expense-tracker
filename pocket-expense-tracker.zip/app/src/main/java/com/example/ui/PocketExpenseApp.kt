package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.local.TransactionEntity
import com.example.ui.components.TransactionEditorSheet
import com.example.ui.screens.ChartsScreen
import com.example.ui.screens.LedgerScreen
import com.example.ui.theme.PocketExpenseTheme
import com.example.ui.util.LocalAppLanguage
import com.example.ui.util.LocalAppResources
import com.example.ui.util.createLocalizedResources
import com.example.ui.util.str
import com.example.ui.viewmodel.ExpenseTrackerViewModel

private enum class AppDestination {
    LEDGER,
    CHARTS
}

@Composable
fun PocketExpenseApp(viewModel: ExpenseTrackerViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current

    val localizedResources = remember(context, uiState.language) {
        createLocalizedResources(context, uiState.language)
    }

    var currentDestination by remember { mutableStateOf(AppDestination.LEDGER) }
    var isEditorOpen by remember { mutableStateOf(false) }
    var editingTransaction by remember { mutableStateOf<TransactionEntity?>(null) }
    var pendingDeleteTransaction by remember { mutableStateOf<TransactionEntity?>(null) }

    // Support predictive/standard back from Charts tab to Ledger tab
    BackHandler(enabled = currentDestination == AppDestination.CHARTS) {
        currentDestination = AppDestination.LEDGER
    }

    CompositionLocalProvider(
        LocalAppResources provides localizedResources,
        LocalAppLanguage provides uiState.language
    ) {
        PocketExpenseTheme(language = uiState.language) {
            BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                val useNavigationRail = maxWidth >= 600.dp

                Scaffold(
                    containerColor = MaterialTheme.colorScheme.background,
                    contentWindowInsets = WindowInsets.safeDrawing,
                    bottomBar = {
                        if (!useNavigationRail) {
                            NavigationBar(
                                containerColor = MaterialTheme.colorScheme.surface,
                                tonalElevation = 2.dp
                            ) {
                                NavigationBarItem(
                                    selected = currentDestination == AppDestination.LEDGER,
                                    onClick = { currentDestination = AppDestination.LEDGER },
                                    icon = {
                                        Icon(
                                            imageVector = if (currentDestination == AppDestination.LEDGER) {
                                                Icons.Rounded.ReceiptLong
                                            } else {
                                                Icons.Outlined.ReceiptLong
                                            },
                                            contentDescription = str(R.string.nav_ledger)
                                        )
                                    },
                                    label = { Text(str(R.string.nav_ledger)) },
                                    modifier = Modifier.testTag("nav_ledger_item")
                                )
                                NavigationBarItem(
                                    selected = currentDestination == AppDestination.CHARTS,
                                    onClick = { currentDestination = AppDestination.CHARTS },
                                    icon = {
                                        Icon(
                                            imageVector = if (currentDestination == AppDestination.CHARTS) {
                                                Icons.Rounded.BarChart
                                            } else {
                                                Icons.Outlined.BarChart
                                            },
                                            contentDescription = str(R.string.nav_charts)
                                        )
                                    },
                                    label = { Text(str(R.string.nav_charts)) },
                                    modifier = Modifier.testTag("nav_charts_item")
                                )
                            }
                        }
                    },
                    floatingActionButton = {
                        if (!useNavigationRail) {
                            ExtendedFloatingActionButton(
                                onClick = {
                                    editingTransaction = null
                                    isEditorOpen = true
                                },
                                icon = {
                                    Icon(
                                        imageVector = Icons.Rounded.Add,
                                        contentDescription = str(R.string.cd_add_transaction)
                                    )
                                },
                                text = { Text(str(R.string.add_transaction)) },
                                shape = RoundedCornerShape(18.dp),
                                containerColor = MaterialTheme.colorScheme.primary,
                                contentColor = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.testTag("add_transaction_fab")
                            )
                        }
                    }
                ) { innerPadding ->
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        if (useNavigationRail) {
                            NavigationRail(
                                containerColor = MaterialTheme.colorScheme.surface,
                                header = {
                                    FloatingActionButton(
                                        onClick = {
                                            editingTransaction = null
                                            isEditorOpen = true
                                        },
                                        containerColor = MaterialTheme.colorScheme.primary,
                                        contentColor = MaterialTheme.colorScheme.onPrimary,
                                        modifier = Modifier
                                            .padding(top = 8.dp)
                                            .testTag("add_transaction_fab")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.Add,
                                            contentDescription = str(R.string.cd_add_transaction)
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(12.dp))
                                }
                            ) {
                                NavigationRailItem(
                                    selected = currentDestination == AppDestination.LEDGER,
                                    onClick = { currentDestination = AppDestination.LEDGER },
                                    icon = {
                                        Icon(
                                            imageVector = if (currentDestination == AppDestination.LEDGER) {
                                                Icons.Rounded.ReceiptLong
                                            } else {
                                                Icons.Outlined.ReceiptLong
                                            },
                                            contentDescription = str(R.string.nav_ledger)
                                        )
                                    },
                                    label = { Text(str(R.string.nav_ledger)) },
                                    modifier = Modifier.testTag("nav_ledger_item")
                                )
                                NavigationRailItem(
                                    selected = currentDestination == AppDestination.CHARTS,
                                    onClick = { currentDestination = AppDestination.CHARTS },
                                    icon = {
                                        Icon(
                                            imageVector = if (currentDestination == AppDestination.CHARTS) {
                                                Icons.Rounded.BarChart
                                            } else {
                                                Icons.Outlined.BarChart
                                            },
                                            contentDescription = str(R.string.nav_charts)
                                        )
                                    },
                                    label = { Text(str(R.string.nav_charts)) },
                                    modifier = Modifier.testTag("nav_charts_item")
                                )
                            }
                        }

                        when (currentDestination) {
                            AppDestination.LEDGER -> {
                                LedgerScreen(
                                    uiState = uiState,
                                    onFilterChange = viewModel::setFilter,
                                    onCategoryToggle = viewModel::toggleCategoryFilter,
                                    onSearchChange = viewModel::setSearchQuery,
                                    onClearFilters = viewModel::clearFilters,
                                    onEditTransaction = { tx ->
                                        editingTransaction = tx
                                        isEditorOpen = true
                                    },
                                    onDeleteTransaction = { tx ->
                                        pendingDeleteTransaction = tx
                                    },
                                    onToggleLanguage = viewModel::toggleLanguage,
                                    onCycleCurrency = viewModel::cycleCurrency,
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            AppDestination.CHARTS -> {
                                ChartsScreen(
                                    uiState = uiState,
                                    onPreviousMonth = viewModel::previousMonth,
                                    onNextMonth = viewModel::nextMonth,
                                    onChartTabChange = viewModel::setChartTab,
                                    onToggleLanguage = viewModel::toggleLanguage,
                                    onCycleCurrency = viewModel::cycleCurrency,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }

                if (isEditorOpen) {
                    TransactionEditorSheet(
                        editingTransaction = editingTransaction,
                        currency = uiState.currency,
                        language = uiState.language,
                        onDismiss = {
                            isEditorOpen = false
                            editingTransaction = null
                        },
                        onSave = { type, amount, description, category, timestamp ->
                            val target = editingTransaction
                            if (target == null) {
                                viewModel.addTransaction(
                                    type = type,
                                    amount = amount,
                                    description = description,
                                    category = category,
                                    timestamp = timestamp
                                )
                            } else {
                                viewModel.updateTransaction(
                                    original = target,
                                    type = type,
                                    amount = amount,
                                    description = description,
                                    category = category,
                                    timestamp = timestamp
                                )
                            }
                            isEditorOpen = false
                            editingTransaction = null
                        },
                        onRequestDelete = { tx ->
                            isEditorOpen = false
                            editingTransaction = null
                            pendingDeleteTransaction = tx
                        }
                    )
                }

                pendingDeleteTransaction?.let { txToDelete ->
                    AlertDialog(
                        onDismissRequest = { pendingDeleteTransaction = null },
                        title = { Text(str(R.string.confirm_delete_title)) },
                        text = { Text(str(R.string.confirm_delete_message)) },
                        confirmButton = {
                            TextButton(
                                onClick = {
                                    viewModel.deleteTransaction(txToDelete)
                                    pendingDeleteTransaction = null
                                },
                                colors = ButtonDefaults.textButtonColors(
                                    contentColor = MaterialTheme.colorScheme.error
                                ),
                                modifier = Modifier.testTag("confirm_delete_button")
                            ) {
                                Text(str(R.string.delete_button))
                            }
                        },
                        dismissButton = {
                            TextButton(
                                onClick = { pendingDeleteTransaction = null },
                                modifier = Modifier.testTag("cancel_delete_button")
                            ) {
                                Text(str(R.string.cancel_button))
                            }
                        }
                    )
                }
            }
        }
    }
}
