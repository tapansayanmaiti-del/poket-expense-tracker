package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.TransactionEntity
import com.example.data.model.AppLanguage
import com.example.data.model.CurrencyOption
import com.example.data.model.MonthYear
import com.example.data.model.TransactionCategory
import com.example.data.model.TransactionType
import com.example.data.preferences.UserPreferencesRepository
import com.example.data.repository.TransactionRepository
import java.util.Calendar
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class TransactionFilter {
    ALL,
    INCOME,
    EXPENSE
}

enum class ChartTab {
    DAILY,
    SIX_MONTHS
}

data class CategorySpend(
    val category: TransactionCategory,
    val amount: Double,
    val percentage: Double
)

data class DailySpend(
    val dayOfMonth: Int,
    val amount: Double
)

data class MonthlyTrend(
    val monthYear: MonthYear,
    val income: Double,
    val expense: Double
)

data class ExpenseTrackerUiState(
    val allTransactions: List<TransactionEntity> = emptyList(),
    val filteredTransactions: List<TransactionEntity> = emptyList(),
    val totalIncome: Double = 0.0,
    val totalExpense: Double = 0.0,
    val remainingBalance: Double = 0.0,
    val selectedFilter: TransactionFilter = TransactionFilter.ALL,
    val selectedCategoryFilter: TransactionCategory? = null,
    val searchQuery: String = "",
    val selectedMonthYear: MonthYear = currentMonthYear(),
    val chartTab: ChartTab = ChartTab.DAILY,
    val language: AppLanguage = AppLanguage.ENGLISH,
    val currency: CurrencyOption = CurrencyOption.BDT,
    val monthlyIncome: Double = 0.0,
    val monthlyExpense: Double = 0.0,
    val monthlyNet: Double = 0.0,
    val categoryBreakdown: List<CategorySpend> = emptyList(),
    val dailySpending: List<DailySpend> = emptyList(),
    val sixMonthTrend: List<MonthlyTrend> = emptyList(),
    val isLoading: Boolean = true
)

private fun currentMonthYear(): MonthYear {
    val cal = Calendar.getInstance()
    return MonthYear(
        year = cal.get(Calendar.YEAR),
        month = cal.get(Calendar.MONTH)
    )
}

class ExpenseTrackerViewModel(
    private val repository: TransactionRepository,
    private val preferences: UserPreferencesRepository
) : ViewModel() {

    private val selectedFilter = MutableStateFlow(TransactionFilter.ALL)
    private val selectedCategoryFilter = MutableStateFlow<TransactionCategory?>(null)
    private val searchQuery = MutableStateFlow("")
    private val selectedMonthYear = MutableStateFlow(currentMonthYear())
    private val chartTab = MutableStateFlow(ChartTab.DAILY)

    private val filterControlsFlow = combine(
        selectedFilter,
        selectedCategoryFilter,
        searchQuery,
        selectedMonthYear,
        chartTab
    ) { filter, category, query, monthYear, tab ->
        FilterControls(filter, category, query, monthYear, tab)
    }

    val uiState: StateFlow<ExpenseTrackerUiState> = combine(
        repository.allTransactions,
        preferences.languageFlow,
        preferences.currencyFlow,
        filterControlsFlow
    ) { transactions, language, currency, controls ->
        buildUiState(transactions, language, currency, controls)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = ExpenseTrackerUiState()
    )

    private fun buildUiState(
        transactions: List<TransactionEntity>,
        language: AppLanguage,
        currency: CurrencyOption,
        controls: FilterControls
    ): ExpenseTrackerUiState {
        var totalIncome = 0.0
        var totalExpense = 0.0
        for (tx in transactions) {
            if (tx.type == TransactionType.INCOME) totalIncome += tx.amount
            else totalExpense += tx.amount
        }

        val queryLower = controls.searchQuery.trim().lowercase()
        val filtered = transactions.filter { tx ->
            val matchesType = when (controls.filter) {
                TransactionFilter.ALL -> true
                TransactionFilter.INCOME -> tx.type == TransactionType.INCOME
                TransactionFilter.EXPENSE -> tx.type == TransactionType.EXPENSE
            }
            val matchesCategory = controls.category == null ||
                (tx.type == TransactionType.EXPENSE && tx.category == controls.category)
            val matchesQuery = queryLower.isEmpty() ||
                tx.description.lowercase().contains(queryLower)
            matchesType && matchesCategory && matchesQuery
        }

        val cal = Calendar.getInstance()
        val targetMonth = controls.monthYear
        var monthlyIncome = 0.0
        var monthlyExpense = 0.0
        val categoryTotals = linkedMapOf<TransactionCategory, Double>()
        TransactionCategory.entries.forEach { categoryTotals[it] = 0.0 }

        cal.set(Calendar.YEAR, targetMonth.year)
        cal.set(Calendar.MONTH, targetMonth.month)
        cal.set(Calendar.DAY_OF_MONTH, 1)
        val daysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
        val dailyTotals = DoubleArray(daysInMonth + 1)

        // Prepare 6-month window ending at targetMonth
        val sixMonths = buildList {
            var cursor = targetMonth
            repeat(6) {
                add(0, cursor)
                cursor = cursor.previous()
            }
        }
        val trendIncome = DoubleArray(6)
        val trendExpense = DoubleArray(6)

        for (tx in transactions) {
            cal.timeInMillis = tx.timestamp
            val txYear = cal.get(Calendar.YEAR)
            val txMonth = cal.get(Calendar.MONTH)
            val txDay = cal.get(Calendar.DAY_OF_MONTH)

            if (txYear == targetMonth.year && txMonth == targetMonth.month) {
                if (tx.type == TransactionType.INCOME) {
                    monthlyIncome += tx.amount
                } else {
                    monthlyExpense += tx.amount
                    categoryTotals[tx.category] = (categoryTotals[tx.category] ?: 0.0) + tx.amount
                    if (txDay in 1..daysInMonth) {
                        dailyTotals[txDay] += tx.amount
                    }
                }
            }

            val trendIdx = sixMonths.indexOfFirst { it.year == txYear && it.month == txMonth }
            if (trendIdx >= 0) {
                if (tx.type == TransactionType.INCOME) trendIncome[trendIdx] += tx.amount
                else trendExpense[trendIdx] += tx.amount
            }
        }

        val categoryBreakdown = categoryTotals.entries
            .filter { it.value > 0.0 }
            .sortedByDescending { it.value }
            .map { (cat, amt) ->
                CategorySpend(
                    category = cat,
                    amount = amt,
                    percentage = if (monthlyExpense > 0.0) (amt / monthlyExpense) * 100.0 else 0.0
                )
            }

        val dailySpending = (1..daysInMonth).map { day ->
            DailySpend(dayOfMonth = day, amount = dailyTotals[day])
        }

        val sixMonthTrend = sixMonths.mapIndexed { idx, ym ->
            MonthlyTrend(
                monthYear = ym,
                income = trendIncome[idx],
                expense = trendExpense[idx]
            )
        }

        return ExpenseTrackerUiState(
            allTransactions = transactions,
            filteredTransactions = filtered,
            totalIncome = totalIncome,
            totalExpense = totalExpense,
            remainingBalance = totalIncome - totalExpense,
            selectedFilter = controls.filter,
            selectedCategoryFilter = controls.category,
            searchQuery = controls.searchQuery,
            selectedMonthYear = targetMonth,
            chartTab = controls.tab,
            language = language,
            currency = currency,
            monthlyIncome = monthlyIncome,
            monthlyExpense = monthlyExpense,
            monthlyNet = monthlyIncome - monthlyExpense,
            categoryBreakdown = categoryBreakdown,
            dailySpending = dailySpending,
            sixMonthTrend = sixMonthTrend,
            isLoading = false
        )
    }

    fun addTransaction(
        type: TransactionType,
        amount: Double,
        description: String,
        category: TransactionCategory,
        timestamp: Long
    ) {
        viewModelScope.launch {
            repository.insert(
                TransactionEntity(
                    type = type,
                    amount = amount,
                    description = description.trim(),
                    category = if (type == TransactionType.INCOME) TransactionCategory.OTHERS else category,
                    timestamp = timestamp
                )
            )
        }
    }

    fun updateTransaction(
        original: TransactionEntity,
        type: TransactionType,
        amount: Double,
        description: String,
        category: TransactionCategory,
        timestamp: Long
    ) {
        viewModelScope.launch {
            repository.update(
                original.copy(
                    type = type,
                    amount = amount,
                    description = description.trim(),
                    category = if (type == TransactionType.INCOME) TransactionCategory.OTHERS else category,
                    timestamp = timestamp
                )
            )
        }
    }

    fun deleteTransaction(transaction: TransactionEntity) {
        viewModelScope.launch {
            repository.delete(transaction)
        }
    }

    fun setFilter(filter: TransactionFilter) {
        selectedFilter.value = filter
        if (filter == TransactionFilter.INCOME) {
            selectedCategoryFilter.value = null
        }
    }

    fun toggleCategoryFilter(category: TransactionCategory) {
        if (selectedCategoryFilter.value == category) {
            selectedCategoryFilter.value = null
        } else {
            selectedCategoryFilter.value = category
            selectedFilter.value = TransactionFilter.EXPENSE
        }
    }

    fun clearFilters() {
        selectedFilter.value = TransactionFilter.ALL
        selectedCategoryFilter.value = null
        searchQuery.value = ""
    }

    fun setSearchQuery(query: String) {
        searchQuery.value = query
    }

    fun previousMonth() {
        selectedMonthYear.value = selectedMonthYear.value.previous()
    }

    fun nextMonth() {
        selectedMonthYear.value = selectedMonthYear.value.next()
    }

    fun setChartTab(tab: ChartTab) {
        chartTab.value = tab
    }

    fun toggleLanguage() {
        val nextLang = if (uiState.value.language == AppLanguage.ENGLISH) {
            AppLanguage.BENGALI
        } else {
            AppLanguage.ENGLISH
        }
        viewModelScope.launch {
            preferences.setLanguage(nextLang)
        }
    }

    fun cycleCurrency() {
        val nextCurrency = uiState.value.currency.next()
        viewModelScope.launch {
            preferences.setCurrency(nextCurrency)
        }
    }

    private data class FilterControls(
        val filter: TransactionFilter,
        val category: TransactionCategory?,
        val searchQuery: String,
        val monthYear: MonthYear,
        val tab: ChartTab
    )

    class Factory(
        private val repository: TransactionRepository,
        private val preferences: UserPreferencesRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(ExpenseTrackerViewModel::class.java)) {
                return ExpenseTrackerViewModel(repository, preferences) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
        }
    }
}
