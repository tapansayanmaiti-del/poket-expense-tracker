package com.example.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.Category
import androidx.compose.material.icons.rounded.DirectionsCar
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material.icons.rounded.Restaurant
import androidx.compose.material.icons.rounded.ShoppingBag
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.data.model.TransactionCategory
import com.example.ui.theme.LocalLedgerColors

@Composable
fun TransactionCategory.color(): Color {
    val ledgerColors = LocalLedgerColors.current
    return when (this) {
        TransactionCategory.FOOD -> ledgerColors.categoryFood
        TransactionCategory.SHOPPING -> ledgerColors.categoryShopping
        TransactionCategory.TRAVEL -> ledgerColors.categoryTravel
        TransactionCategory.BILLS -> ledgerColors.categoryBills
        TransactionCategory.OTHERS -> ledgerColors.categoryOthers
    }
}

fun TransactionCategory.icon(): ImageVector = when (this) {
    TransactionCategory.FOOD -> Icons.Rounded.Restaurant
    TransactionCategory.SHOPPING -> Icons.Rounded.ShoppingBag
    TransactionCategory.TRAVEL -> Icons.Rounded.DirectionsCar
    TransactionCategory.BILLS -> Icons.Rounded.ReceiptLong
    TransactionCategory.OTHERS -> Icons.Rounded.Category
}

val IncomeIcon: ImageVector = Icons.Rounded.AccountBalanceWallet
