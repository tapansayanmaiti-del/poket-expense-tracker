package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.TransactionEntity
import com.example.data.model.AppLanguage
import com.example.data.model.TransactionCategory
import com.example.ui.components.BalanceHeroCard
import com.example.ui.components.TransactionCard
import com.example.ui.components.color
import com.example.ui.components.icon
import com.example.ui.util.Formatters
import com.example.ui.util.LocalAppResources
import com.example.ui.util.str
import com.example.ui.util.titleResId
import com.example.ui.viewmodel.ExpenseTrackerUiState
import com.example.ui.viewmodel.TransactionFilter

@Composable
fun LedgerScreen(
    uiState: ExpenseTrackerUiState,
    onFilterChange: (TransactionFilter) -> Unit,
    onCategoryToggle: (TransactionCategory) -> Unit,
    onSearchChange: (String) -> Unit,
    onClearFilters: () -> Unit,
    onEditTransaction: (TransactionEntity) -> Unit,
    onDeleteTransaction: (TransactionEntity) -> Unit,
    onToggleLanguage: () -> Unit,
    onCycleCurrency: () -> Unit,
    modifier: Modifier = Modifier
) {
    val resources = LocalAppResources.current
    val groupedTransactions = remember(uiState.filteredTransactions, uiState.language, resources) {
        uiState.filteredTransactions.groupBy { tx ->
            Formatters.formatDateGroupHeader(tx.timestamp, uiState.language, resources)
        }
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 760.dp)
                .fillMaxSize()
                .testTag("ledger_list"),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 104.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item(key = "header") {
                LedgerTopHeader(
                    language = uiState.language,
                    currencySymbol = uiState.currency.symbol,
                    onToggleLanguage = onToggleLanguage,
                    onCycleCurrency = onCycleCurrency
                )
            }

            item(key = "hero_card") {
                BalanceHeroCard(
                    remainingBalance = uiState.remainingBalance,
                    totalIncome = uiState.totalIncome,
                    totalExpense = uiState.totalExpense,
                    currency = uiState.currency,
                    language = uiState.language
                )
            }

            item(key = "search_bar") {
                OutlinedTextField(
                    value = uiState.searchQuery,
                    onValueChange = onSearchChange,
                    placeholder = {
                        Text(
                            text = str(R.string.search_placeholder),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Rounded.Search,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    },
                    trailingIcon = {
                        if (uiState.searchQuery.isNotEmpty()) {
                            IconButton(
                                onClick = { onSearchChange("") },
                                modifier = Modifier.testTag("clear_search_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Close,
                                    contentDescription = str(R.string.cd_clear_search)
                                )
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_input")
                )
            }

            item(key = "filter_chips") {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        FilterChip(
                            selected = uiState.selectedFilter == TransactionFilter.ALL &&
                                uiState.selectedCategoryFilter == null,
                            onClick = { onClearFilters() },
                            label = { Text(str(R.string.filter_all)) },
                            modifier = Modifier.testTag("filter_all_chip")
                        )
                    }
                    item {
                        FilterChip(
                            selected = uiState.selectedFilter == TransactionFilter.INCOME,
                            onClick = { onFilterChange(TransactionFilter.INCOME) },
                            label = { Text(str(R.string.filter_income)) },
                            modifier = Modifier.testTag("filter_income_chip")
                        )
                    }
                    item {
                        FilterChip(
                            selected = uiState.selectedFilter == TransactionFilter.EXPENSE &&
                                uiState.selectedCategoryFilter == null,
                            onClick = {
                                if (uiState.selectedCategoryFilter != null) {
                                    onClearFilters()
                                    onFilterChange(TransactionFilter.EXPENSE)
                                } else {
                                    onFilterChange(TransactionFilter.EXPENSE)
                                }
                            },
                            label = { Text(str(R.string.filter_expense)) },
                            modifier = Modifier.testTag("filter_expense_chip")
                        )
                    }
                    items(TransactionCategory.entries) { category ->
                        val isSelected = uiState.selectedCategoryFilter == category
                        val catColor = category.color()
                        FilterChip(
                            selected = isSelected,
                            onClick = { onCategoryToggle(category) },
                            label = { Text(str(category.titleResId())) },
                            leadingIcon = {
                                Icon(
                                    imageVector = category.icon(),
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = catColor.copy(alpha = 0.16f),
                                selectedLabelColor = catColor,
                                selectedLeadingIconColor = catColor
                            ),
                            modifier = Modifier.testTag("filter_category_${category.name.lowercase()}")
                        )
                    }
                }
            }

            item(key = "history_header") {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = str(R.string.transaction_history),
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "${
                            Formatters.localizeDigits(
                                uiState.filteredTransactions.size.toString(),
                                uiState.language
                            )
                        } ${str(R.string.entries_suffix)}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (uiState.allTransactions.isEmpty()) {
                item(key = "empty_state") {
                    EmptyLedgerCard(
                        title = str(R.string.empty_history_title),
                        subtitle = str(R.string.empty_history_subtitle),
                        showIllustration = true
                    )
                }
            } else if (uiState.filteredTransactions.isEmpty()) {
                item(key = "empty_filter_state") {
                    EmptyLedgerCard(
                        title = str(R.string.empty_filter_title),
                        subtitle = str(R.string.empty_filter_subtitle),
                        showIllustration = false,
                        actionLabel = str(R.string.filter_all),
                        onAction = onClearFilters
                    )
                }
            } else {
                groupedTransactions.forEach { (dateLabel, list) ->
                    item(key = "group_$dateLabel") {
                        Text(
                            text = dateLabel,
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(top = 6.dp, bottom = 2.dp)
                        )
                    }
                    items(
                        items = list,
                        key = { it.id }
                    ) { transaction ->
                        TransactionCard(
                            transaction = transaction,
                            currency = uiState.currency,
                            language = uiState.language,
                            onEdit = { onEditTransaction(transaction) },
                            onDelete = { onDeleteTransaction(transaction) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun LedgerTopHeader(
    language: AppLanguage,
    currencySymbol: String,
    onToggleLanguage: () -> Unit,
    onCycleCurrency: () -> Unit,
    titleOverride: String? = null,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = titleOverride ?: str(R.string.app_name),
            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onBackground,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )

        Spacer(modifier = Modifier.width(8.dp))

        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                modifier = Modifier
                    .height(40.dp)
                    .clip(RoundedCornerShape(50))
                    .clickable(onClick = onCycleCurrency)
                    .testTag("currency_toggle_button"),
                shape = RoundedCornerShape(50),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Box(
                    modifier = Modifier.padding(horizontal = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = currencySymbol,
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            Surface(
                modifier = Modifier
                    .height(40.dp)
                    .clip(RoundedCornerShape(50))
                    .clickable(onClick = onToggleLanguage)
                    .testTag("language_toggle_button"),
                shape = RoundedCornerShape(50),
                color = MaterialTheme.colorScheme.primaryContainer,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.25f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Language,
                        contentDescription = str(R.string.cd_toggle_language),
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = if (language == AppLanguage.ENGLISH) {
                            str(R.string.language_bn)
                        } else {
                            str(R.string.language_en)
                        },
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
        }
    }
}

@Composable
private fun EmptyLedgerCard(
    title: String,
    subtitle: String,
    showIllustration: Boolean,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp)
            .testTag("empty_ledger_card"),
        shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (showIllustration) {
                Image(
                    painter = painterResource(id = R.drawable.img_empty_ledger),
                    contentDescription = str(R.string.cd_empty_ledger_art),
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(155.dp)
                        .clip(RoundedCornerShape(18.dp))
                )
                Spacer(modifier = Modifier.height(4.dp))
            }
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Center
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            if (actionLabel != null && onAction != null) {
                TextButton(onClick = onAction) {
                    Text(actionLabel)
                }
            }
        }
    }
}
