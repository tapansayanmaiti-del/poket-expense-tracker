package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.ViewModelProvider
import com.example.data.local.AppDatabase
import com.example.data.preferences.UserPreferencesRepository
import com.example.data.repository.TransactionRepository
import com.example.ui.PocketExpenseApp
import com.example.ui.viewmodel.ExpenseTrackerViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val database = AppDatabase.getInstance(applicationContext)
        val repository = TransactionRepository(database.transactionDao())
        val preferences = UserPreferencesRepository(applicationContext)
        val viewModel = ViewModelProvider(
            this,
            ExpenseTrackerViewModel.Factory(repository, preferences)
        )[ExpenseTrackerViewModel::class.java]

        setContent {
            PocketExpenseApp(viewModel = viewModel)
        }
    }
}
